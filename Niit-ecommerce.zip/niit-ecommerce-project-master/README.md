# niit-ecommerce-project
#fashion shop

Classes:

Category 1-------many Product many------1 User-----Many Address
OrderItem Many----1 Order Many ----1 User 1-----1 Cart 1----Many CartItem 1---1 Product
OrderItem 1----1 Product
Supplier
Admin


[![ecommerce homepage](https://github.com/PrashanthiRamesh/niit-ecommerce-project/blob/master/ecommerceproject/src/main/webapp/assets/img/readme1.png)]

